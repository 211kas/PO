import java.util.ArrayList;

public class FoodQueue {
    private final ArrayList<Food> queueFood;

    public FoodQueue() {
        this.queueFood = new ArrayList<>();
    }

    public void add(Food food) {
        queueFood.add(food);
    }

    public void checkAllFoods(Snake snake) {
        for (int i = 0; i < queueFood.size(); i++) {
            Food currentFoods = queueFood.get(i);
            if (currentFoods.getStatus() == Food.IN_PROGRESS )
                continue;

            if (currentFoods.getStatus() == Food.FINISHED) {
                queueFood.remove(i--);
                continue;
            }

            checkFood(currentFoods, snake);
        }
    }

    public void checkFood(Food currentFood, Snake snake) {
        if (snake.getMode() == Snake.GameMode.AUTO){
            Trajetoria [] t = snake.checkFood(currentFood);
            int index = lowestDistance(t);
            if (index != -1) {
                snake.setFoodRequest(t[index], currentFood);
            }
        } else if (snake.getMode() == Snake.GameMode.MANUAL) {
            snake.setCurrentFood(currentFood);
        }
    }

    public int lowestDistance(Trajetoria[] q) {
        if (q == null) return -1;
        int lowest = Integer.MAX_VALUE;
        int result = -1;
        for (int i = 0; i < q.length; i++)
            if (q[i] != null && q[i].size() < lowest) {
                lowest = q[i].size();
                result = i;
            }
        return result;
    }


    public Food[] getRequestsArray() {
        return queueFood.toArray(new Food[0]);
    }

    @Override
    public String toString() {
        Food[] x = queueFood.toArray(new Food[0]);
        StringBuilder result = new StringBuilder();
        for (Food request : x)
            result.append(request.getStatus()).append(" - ");

        return result.toString();
    }

    public ArrayList<Food> getQueueFood() {
        return queueFood;
    }
}
