import java.util.*;

interface AStar {

    private static LinkedList<Node> allPath(Node endNode) {
        LinkedList<Node> result = new LinkedList<>(); // Using linked list because inserting at start O(1)
        result.add(endNode);
        Node currentNode = endNode;

        while (currentNode.getParent() != null) {
            result.addFirst(currentNode.getParent()); //O(1)
            currentNode = currentNode.getParent();
        }

        return result;
    }

    private static Node[] getNeighbours(Node[] nodeNeighbours, Ponto<Integer> currentNewPoint, SegmentoReta currentNewLine, Node[][] gridNodes, Node currentNode, Obstaculo[] obstacles, int[] dx, int[] dy, int[] gCost, int squareSize) {
        // Reset nodes
        Arrays.fill(nodeNeighbours, null);

        int x = currentNode.getP().getX();
        int y = currentNode.getP().getY();

        currentNewLine.setP1(currentNode.getP());

        for (int i = 0; i < 8; i++) {
            int nx = x + dx[i] * squareSize;
            int ny = y + dy[i] * squareSize;

            if (nx >= 0 && ny >= 0 && nx < gridNodes.length && ny < gridNodes[0].length) {
                currentNewPoint.setX(nx);
                currentNewPoint.setY(ny);
                currentNewLine.setP2(currentNewPoint);
                if (!currentNewLine.intersectsObstacles(obstacles)) { // Slowest thing to do here
                    int tryGCost = currentNode.getgCost() + gCost[i];
                    if (tryGCost < gridNodes[nx][ny].getgCost()) {
                        gridNodes[nx][ny].setgCost(tryGCost);
                        nodeNeighbours[i] = gridNodes[nx][ny];
                    }
                }
            }
        }

        return nodeNeighbours;
    }

    default LinkedList<Node> bestPath(Ponto<Integer> start, Ponto<Integer> end, Obstaculo[] obstacles, int squareSize) {
        PriorityQueue<Node> openNodes = new PriorityQueue<>(Node::comparator); // Adding and removing the lowest value is O(log n)
        HashSet<Node> closedNodes = new HashSet<>(); // contains() is O(1)
        Node[][] gridNodes = new Node[1000][1000]; // Faster, but wastes lots of space

        for (int i = 0; i < gridNodes.length; i++)
            for (int j = 0; j < gridNodes[0].length; j++)
                gridNodes[i][j] = new Node(new Ponto<>(i, j), Integer.MAX_VALUE, Integer.MAX_VALUE);

        final Node startNode = new Node(start, 0, 0);
        startNode.sethCost(startNode.calculateDistance(end));
        openNodes.add(startNode);

        // We are saving space so that we don't need to allocate memory everytime we need the neighbours
        final Node[] nodeNeighbours = new Node[8]; // utility for neighbours
        final Ponto<Integer> currentNewPoint = new Ponto<>(1002, 1002); // avoid creating 8 points for every neighbour
        final SegmentoReta currentNewLine = new SegmentoReta(new Ponto<>(0, 0), currentNewPoint); // avoid creating 8 lines for every neighbour
        final int[] dx = {-1, 0, 1, -1, 1, -1, 0, 1};
        final int[] dy = {-1, -1, -1, 0, 0, 1, 1, 1};
        final int[] gCost = {14, 10, 14, 10, 10, 14, 10, 14};


        while (!openNodes.isEmpty()) { // O(1)
            Node currentNode = openNodes.poll(); // O(log n)
            if (currentNode.isEqualToPoint(end))
                return allPath(currentNode);

            closedNodes.add(currentNode); // O(1)
            Node[] neighbours = getNeighbours(nodeNeighbours, currentNewPoint, currentNewLine, gridNodes, currentNode, obstacles, dx, dy, gCost, squareSize);
            for (Node neighbourNode : neighbours) {
                if (neighbourNode == null || closedNodes.contains(neighbourNode)) continue;  // O(1)

                neighbourNode.setParent(currentNode);
                neighbourNode.sethCost(neighbourNode.calculateDistance(end));

                openNodes.add(neighbourNode);  // O(log n)
            }
        }
        return null;
    }
}
