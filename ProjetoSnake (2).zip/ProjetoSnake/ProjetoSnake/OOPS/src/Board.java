import java.awt.*;
import java.util.Random;

public class Board {
    private final Client client;
    private Manager manager;
    private Snake snake;
    private FoodQueue foods;
    private Obstaculo[] obstacles;
    private BoardCell[][] cells;
    private int width;
    private int height;

    public Board(Client client, int screenWidth, int screenHeight, int cellSize, Snake.GameMode m) {
        this.client = client;
        this.manager = client.getManager();
        this.width = screenWidth;
        this.height = screenHeight;
        this.cells = new BoardCell[height][width];
        for (int i = 0; i < height; i++) {
            for (int j = 0; j < width; j++) {
                cells[i][j] = new BoardCell();
            }
        }
        initializeSnakeAtCenter(cellSize, m);
        this.foods = manager.getFoodQueue();
        this.obstacles = snake.getObstacles();
    }

    public void update() {
        snake.update();
        for (int i = 0; i < height; i++) {
            for (int j = 0; j < width; j++) {
                cells[i][j].setOccupiedByFood(false);
                cells[i][j].setOccupiedBySnakeHead(false);
                cells[i][j].setOccupiedBySnakeBody(false);
            }
        }
        for (Quadrado segment : snake.getBody()) {
            boolean isHead = snake.getBody().indexOf(segment) == 0;
            for (int dx = 0; dx < snake.getSquareSize(); dx++) {
                for (int dy = 0; dy < snake.getSquareSize(); dy++) {
                    int x = (int) (segment.getCentro().getX() + dx);
                    int y = (int) (segment.getCentro().getY() + dy);
                    if (x >= 0 && x < width && y >= 0 && y < height) {
                        if (isHead) {
                            cells[y][x].setOccupiedBySnakeHead(true);
                        } else {
                            cells[y][x].setOccupiedBySnakeBody(true);
                        }
                    }
                }
            }
        }
        for (Food food : foods.getQueueFood()) {
            int x = food.getFoodPoint().getX();
            int y = food.getFoodPoint().getY();
            if (x >= 0 && x < width && y >= 0 && y < height) {
                cells[y][x].setOccupiedByFood(true);
            }
        }
    }

    private void initializeSnakeAtCenter(int cellSize, Snake.GameMode m) {
        System.out.println("Inicializando a cobra no centro...");
        int centerX = width / 2;
        int centerY = height / 2;
        snake = new Snake(obstacles, cellSize, m);
        Ponto<Integer>[] pontos = new Ponto[]{
                new Ponto<>(centerX - cellSize / 2, centerY - cellSize / 2), // Canto superior esquerdo
                new Ponto<>(centerX + cellSize / 2 - 1, centerY - cellSize / 2), // Canto superior direito
                new Ponto<>(centerX + cellSize / 2 - 1, centerY + cellSize / 2 - 1), // Canto inferior direito
                new Ponto<>(centerX - cellSize / 2, centerY + cellSize / 2 - 1) // Canto inferior esquerdo
        };

        Quadrado head = new Quadrado(pontos);
        snake.getBody().addFirst(head);
        System.out.println("Cobra inicializada com " + snake.getBody().size() + " segmentos.");
    }




    public BoardCell getCell(int x, int y) {
        if (x >= 0 && x < width && y >= 0 && y < height) {
            return cells[y][x];
        } else {
            return null;
        }
    }

    public void printBoard() {
        for (int i = 0; i < height; i++) {
            for (int j = 0; j < width; j++) {
                BoardCell cell = cells[i][j];
                if (cell.isOccupiedBySnakeHead()) {
                    System.out.print("H ");
                }else if (cell.isOccupiedBySnakeBody()) {
                    System.out.print("T ");
                } else if (cell.isOccupiedByFood()) {
                    System.out.print("F ");
                } else if (cell.isOccupiedByObstacle()) {
                    System.out.print("O ");
                } else {
                    System.out.print(". ");
                }
            }
            System.out.println();
        }
        System.out.println("Dir " + (snake.getCurrentDirection() == null ? "None" : snake.getCurrentDirection()) + ": 0 Pontos: 0");
    }



    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public Snake getSnake() {
        return snake;
    }

    public void setManager(Manager manager) {
        this.manager = manager;
    }
}



