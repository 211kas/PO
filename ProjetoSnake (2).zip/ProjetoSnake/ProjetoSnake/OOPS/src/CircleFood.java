import java.util.LinkedList;

public class CircleFood extends Food {
    private Circulo circle;

    public CircleFood(Snake s, Ponto<Integer> foodPoint, Obstaculo[] obs, int score, Circulo circle) {
        super(s, foodPoint, obs, score);
        this.circle = circle;
    }

    @Override
    public boolean isContainedCompletelyBy(Quadrado snakeHead) {
        for (int angle = 0; angle < 360; angle += 10) {
            double radian = Math.toRadians(angle);
            int x = (int) (circle.getCenter().getX() + circle.getRadius() * Math.cos(radian));
            int y = (int) (circle.getCenter().getY() + circle.getRadius() * Math.sin(radian));
            Ponto<Integer> point = new Ponto<>(x, y);
            if (!snakeHead.contains(point)) {
                return false;
            }
        }
        return true;
    }

}
