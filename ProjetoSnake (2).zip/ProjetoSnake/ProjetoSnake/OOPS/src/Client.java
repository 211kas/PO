import java.io.IOException;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Client {
    private final Manager manager;
    private final Board board;

    public Client() throws IOException, ClassNotFoundException {
        Scanner sc = new Scanner(System.in);
        System.out.print("Choose game mode (Manual or Auto): ");
        String gameModeInput = sc.nextLine().trim().toLowerCase();
        Snake.GameMode gameMode;

        switch (gameModeInput) {
            case "manual":
                gameMode = Snake.GameMode.MANUAL;
                break;
            case "auto":
                gameMode = Snake.GameMode.AUTO;
                break;
            default:
                System.out.println("Invalid game mode. Defaulting to Manual.");
                gameMode = Snake.GameMode.MANUAL;
        }
        System.out.print("Enter board width and height (e.g., 200 200): ");
        int boardWidth = sc.nextInt();
        int boardHeight = sc.nextInt();
        System.out.print("Enter Snake Square size: ");
        int cellSize = sc.nextInt();
        Obstaculo[] initialObstacles = readObs(sc);
        Snake initialSnake = new Snake(initialObstacles, cellSize, gameMode);
        manager = new Manager(initialObstacles, initialSnake);
        board = new Board(this, boardWidth, boardHeight, cellSize, gameMode);
        manager.setSnake(board.getSnake());
        System.out.print("Choose food type (SquareFood or CircleFood): ");
        String foodClassName = sc.next();
        Class<?> foodType = Class.forName(capital(foodClassName));
        System.out.print("Enter food score: ");
        int foodScore = sc.nextInt();
        sc.nextLine();
        manager.generateFood(boardWidth, boardHeight, foodType, foodScore);
        board.update();
        board.printBoard();
        while (true) {
            System.out.print("Choose new Snake Direction (W, A, S, D): ");
            String input = sc.nextLine().trim().toLowerCase();
            if (!input.isEmpty()) {
                switch (input) {
                    case "w": board.getSnake().setCurrentDirection(Snake.Direction.UP); break;
                    case "s": board.getSnake().setCurrentDirection(Snake.Direction.DOWN); break;
                    case "a": board.getSnake().setCurrentDirection(Snake.Direction.LEFT); break;
                    case "d": board.getSnake().setCurrentDirection(Snake.Direction.RIGHT); break;
                    default: continue;
                }
            }
            manager.update();
            board.update();
            board.printBoard();
        }
    }

    private Obstaculo[] readObs(Scanner sc) {
        System.out.print("Number of obstacles: ");
        int n = sc.nextInt();
        sc.nextLine();
        ArrayList<Obstaculo> obstacles = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            System.out.print("Enter obstacle details (type data): ");
            String s = sc.nextLine();
            String[] aux = s.split(" ");
            try {
                Class<?> cl = Class.forName(capital(aux[0]));
                Constructor<?> constructor = cl.getConstructor(String.class);
                Obstaculo obstacle = (Obstaculo) constructor.newInstance(s);
                obstacles.add(obstacle);
            } catch (Exception e) {
                System.out.println("Unknown obstacle type");
                System.exit(0);
            }
        }
        return obstacles.toArray(new Obstaculo[0]);
    }

    public static String capital(String s) {
        if (s == null || s.isEmpty()) return s;
        String[] parts = s.split("(?<!^)(?=[A-Z])");
        StringBuilder sb = new StringBuilder();
        for (String part : parts) {
            if (sb.length() > 0) sb.append("");
            sb.append(Character.toUpperCase(part.charAt(0)));
            sb.append(part.substring(1).toLowerCase());
        }
        return sb.toString();
    }


    public Manager getManager() {
        return manager;
    }

}
