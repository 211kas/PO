import java.util.LinkedList;

public class Snake {
    private LinkedList<Quadrado> body;
    private final Obstaculo[] obstacles;
    private Trajetoria currentTrajectory;
    private Direction currentDirection;

    private GameMode mode;
    private Food currentFood;
    private boolean isAlive;
    private final int squareSize;

    public enum GameMode {
        MANUAL, AUTO
    }


    public enum Direction {
        UP, DOWN, LEFT, RIGHT
    }

    public Snake(Obstaculo[] obstacles, int squareSize, GameMode m) {
        this.obstacles = obstacles;
        this.body = new LinkedList<>();
        this.currentTrajectory = new Trajetoria();
        currentFood = null;
        isAlive = true;
        mode = m;
        this.squareSize = squareSize;
    }

    public Obstaculo[] getObstacles() {
        return obstacles;
    }



    public void move() {
        if (body.isEmpty() || currentDirection == null) {
            return; // Não faz nada se não há corpo ou direção definida.
        }

        // Definindo o deslocamento baseado na direção atual.
        int deltaX = 0, deltaY = 0;
        switch (currentDirection) {
            case UP:
                deltaY = -squareSize;
                break;
            case DOWN:
                deltaY = squareSize;
                break;
            case LEFT:
                deltaX = -squareSize;
                break;
            case RIGHT:
                deltaX = squareSize;
                break;
        }

        LinkedList<Quadrado> newBody = new LinkedList<>();
        for (int i = 0; i < body.size(); i++) {
            Quadrado seg = body.get(i);
            if (i == 0) {
                // Mover a cabeça na direção especificada.
                seg.translation(deltaX, deltaY);
            } else {
                Quadrado frontSeg = body.get(i - 1);
                // Mover o segmento atual na direção do segmento anterior.
                seg.translation(frontSeg.getCentro().getX() - seg.getCentro().getX(),
                        frontSeg.getCentro().getY() - seg.getCentro().getY());
            }
            newBody.add(seg);
        }
        body = newBody; // Atualiza o corpo com a nova configuração.
    }




    public void checkIfFoodIsEaten() {
        if (currentFood != null && !body.isEmpty()) {
            Quadrado head = body.getFirst();
            if (currentFood.isContainedCompletelyBy(head)) {
                eatFood();
            }
        }
    }


    private void eatFood() {
        currentFood.setStatus(2);
        addSegmentToSnake();
        currentFood = null;
    }

    private void addSegmentToSnake() {
        if (body.isEmpty()) return;

        Quadrado lastSegment = body.getLast();
        Ponto<Integer>[] lastSegmentPoints = lastSegment.getPontos();
        Ponto<Integer>[] newSegmentPoints = new Ponto[4];

        for (int i = 0; i < lastSegmentPoints.length; i++) {
            newSegmentPoints[i] = new Ponto<>(
                    lastSegmentPoints[i].getX(),
                    lastSegmentPoints[i].getY()
            );
        }

        Quadrado newSegment = new Quadrado(newSegmentPoints);
        body.addLast(newSegment);
    }




    public void update() {
        move();
        checkIfFoodIsEaten();
    }

    public Trajetoria[] checkFood(Food currentFood) {
        if (currentFood == null || body.isEmpty()) {
            return null;
        }
        Quadrado head = body.getFirst();
        Ponto<Integer>[] headPoints = head.getPontos();
        Trajetoria[] traj = new Trajetoria[headPoints.length];
        int i = 0;
        for (Ponto<Integer> p: headPoints) {
            traj[i++] = new Trajetoria(p, currentFood.getFoodPoint(), obstacles, squareSize);
        }
        return traj;
    }



    public void setFoodRequest(Trajetoria traj, Food food) {
        if (food != null) {
            food.setStatus(Food.IN_PROGRESS);
            currentTrajectory = traj;
            currentFood = food;
        }
    }

    public void setCurrentFood(Food food){
        if (food != null) {
            food.setStatus(Food.IN_PROGRESS);
            currentFood = food;
        }
    }

    public Direction getCurrentDirection() {
        return currentDirection;
    }

    public void setCurrentDirection(Direction newDirection) {
        this.currentDirection = newDirection;
    }

    public LinkedList<Quadrado> getBody() {
        return body;
    }

    public int getSquareSize() {
        return squareSize;
    }

    public GameMode getMode() {
        return mode;
    }
}
