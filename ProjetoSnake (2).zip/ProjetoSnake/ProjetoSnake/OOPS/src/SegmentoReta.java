/**
 * Uma classe Segmento de Reta que é constituido por dois Pontos do primeiro
 * quadrante que compoem um segmento de reta.
 *
 * @author Martinus Boom a75456
 * @version 25/02/2024
 * @inv p1.dist(p2) != 0 A distancia entre os dois pontos tem de ser
 * diferente de zero para formar um segmento de reta.
 */
public class SegmentoReta {
    private Ponto<Integer> p1;
    private Ponto<Integer> p2;

    /**
     * Constroi um Segmento de Reta a partir de Dois Pontos do primeira quadrante
     *
     * @param p1 : Primeiro ponto do Segemento de Reta
     * @param p2 : Segundo ponto do Segemento de Reta
     */
    public SegmentoReta(Ponto<Integer> p1, Ponto<Integer> p2) {
        check(p1, p2);
        this.p1 = p1;
        this.p2 = p2;
    }

    /**
     * Verifica se é um Segemnto de Reta
     *
     * @param p1 : Primeiro ponto do Segemento de Reta
     * @param p2 : Segundo ponto do Segemento de Reta
     */
    public void check(Ponto<Integer> p1, Ponto<Integer> p2){
        if (p1.dist(p2) == 0) {
            System.out.println("Segment:vi");
            System.exit(0);
        }
    }

    /**
     * Verifica se o Ponto p3 coincide com o Segmento de Reta
     *
     * @param p3 : Ponto em questão
     * @return True se o ponto q se encontrar no Segmento de Reta
     */
    public boolean onSegment(Ponto<Integer> p3) {
        return p3.getX() <= Math.max(p1.getX(), p2.getX()) && p3.getX() >= Math.min(p1.getX(), p2.getX()) &&
                p3.getY() <= Math.max(p1.getY(), p2.getY()) && p3.getY() >= Math.min(p1.getY(), p2.getY());
    }

    /**
     * Verifica a orientação do Segmento de Reta
     *
     * @param p3 : Ponto que se encontra no Segemnto de reta
     * @return 0 se p1,p3 e p2 forem colineares
     * @return 1 se a orientação for no sentido do relogio
     * @return 2 se for no sentido contra relogio
     */
    public int orientation(Ponto<Integer> p3) {
        double result = (p2.getY() - p1.getY()) * (p3.getX() - p2.getX()) -
                (p2.getX() - p1.getX()) * (p3.getY() - p2.getY());

        if (result == 0)
            return 0;
        return result > 0 ? 1 : 2;
    }


    /**
     * Verifica se um Segmentos de reta interseta o Segmento de Reta
     *
     * @param r : Segmento de reta em questão
     * @return True se o Segmento 'r' intersetar o Segmento de Reta
     */
    public boolean intersect(SegmentoReta r) {
        int o1 = orientation(r.getP1());
        int o2 = orientation(r.getP2());
        int o3 = r.orientation(p1);
        int o4 = r.orientation(p2);

        if (o1 == 0 && onSegment(r.getP1())) return false;
        if (o2 == 0 && onSegment(r.getP2())) return false;
        if (o3 == 0 && onSegment(p1)) return false;
        if (o4 == 0 && onSegment(p2)) return false;
        return o1 != o2 && o3 != o4;
    }

    /**
     * Checks if line intersects with obstacle
     *
     * @param obs Obstacle to check intersection
     * @return True if line intersects with obstacle
     */
    public boolean intersectsObstacle(Obstaculo obs) {
        return obs.intersectsLine(this);
    }

    public boolean intersectsObstacles(Obstaculo[] obs) {
        if (obs == null)
            return false;

        for (Obstaculo thisObs : obs)
            if (intersectsObstacle(thisObs))
                return true;
        return false;
    }

    /**
     * @return Coordenadas do primeiro Ponto do Segmento de Reta
     */
    public Ponto<Integer> getP1() {
        return p1;
    }

    /**
     * @return Coordenadas do segundo Ponto do Segmento de Reta
     */
    public Ponto<Integer> getP2() {
        return p2;
    }

    public void setP1(Ponto<Integer> newP1) {
        check(newP1, p2);
        this.p1 = newP1;
    }

    public void setP2(Ponto<Integer> newP2) {
        check(p1, newP2);
        this.p2 = newP2;
    }
}
